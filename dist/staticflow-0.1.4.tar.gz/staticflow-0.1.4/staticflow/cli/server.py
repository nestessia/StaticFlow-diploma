import asyncio
from aiohttp import web
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from rich.console import Console
from rich.panel import Panel
from ..core.config import Config
from ..core.engine import Engine

console = Console()

REQUIRED_DIRECTORIES = ['content', 'templates', 'static', 'public']
REQUIRED_FILES = ['config.toml']


def create_welcome_page():
    """Create welcome page and necessary files for new projects."""
    content_dir = Path('content/pages')
    templates_dir = Path('templates')
    static_dir = Path('static/css')
    
    # Create directories if they don't exist
    content_dir.mkdir(parents=True, exist_ok=True)
    templates_dir.mkdir(parents=True, exist_ok=True)
    static_dir.mkdir(parents=True, exist_ok=True)
    
    # Create welcome page
    welcome_content = """---
title: Welcome to StaticFlow
template: base.html
---
<div class="welcome-container">
    <h1 class="welcome-title">Welcome to StaticFlow!</h1>
    
    <div class="welcome-content">
        <p>
            Congratulations! Your StaticFlow site is up and running. 
            Now you can start creating your content.
        </p>
        
        <h2>Getting Started</h2>
        <ol class="steps-list">
            <li>Create content in <code>content/pages/</code> using Markdown or HTML</li>
            <li>Customize templates in <code>templates/</code> directory</li>
            <li>Add your styles to <code>static/css/</code> directory</li>
            <li>Configure your site in <code>config.toml</code></li>
        </ol>
        
        <h2>Example Structure</h2>
        <pre class="file-tree">
project_name/
├── content/
│   └── pages/
│       ├── index.md
│       └── about.md
├── templates/
│   └── base.html
├── static/
│   └── css/
│       └── style.css
├── public/
└── config.toml</pre>
        
        <div class="help-section">
            <h2>Need Help?</h2>
            <p>
                Check out our documentation or visit our GitHub repository 
                for more information.
            </p>
        </div>
    </div>
</div>"""

    # Create base template
    base_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ page.title }}</title>
    <link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
    <main>
        {{ page.content }}
    </main>
</body>
</html>"""

    # Create basic styles
    welcome_styles = """/* Welcome page styles */
body {
    font-family: system-ui, -apple-system, sans-serif;
    line-height: 1.5;
    margin: 0;
    padding: 20px;
    background: #f5f5f5;
}

.welcome-container {
    max-width: 800px;
    margin: 0 auto;
    background: white;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.welcome-title {
    color: #2563eb;
    font-size: 2.5rem;
    text-align: center;
    margin-bottom: 2rem;
}

.welcome-content {
    color: #374151;
}

.steps-list {
    padding-left: 1.5rem;
}

.steps-list li {
    margin-bottom: 0.5rem;
}

code {
    background: #f1f5f9;
    padding: 0.2rem 0.4rem;
    border-radius: 4px;
    font-family: monospace;
}

.file-tree {
    background: #f8fafc;
    padding: 1rem;
    border-radius: 4px;
    font-family: monospace;
    white-space: pre;
    overflow-x: auto;
}

.help-section {
    margin-top: 2rem;
    padding-top: 1rem;
    border-top: 1px solid #e5e7eb;
}"""

    # Write files
    index_path = content_dir / 'index.md'
    template_path = templates_dir / 'base.html'
    style_path = static_dir / 'style.css'
    
    index_path.write_text(welcome_content)
    template_path.write_text(base_template)
    style_path.write_text(welcome_styles)


def validate_project_structure():
    """Validate project structure and permissions."""
    errors = []
    warnings = []
    
    # Check required directories
    for dir_name in REQUIRED_DIRECTORIES:
        dir_path = Path(dir_name)
        if not dir_path.exists():
            errors.append(f"Directory '{dir_name}' not found")
        elif not dir_path.is_dir():
            errors.append(f"'{dir_name}' exists but is not a directory")
        else:
            try:
                # Try to create a temporary file to test write permissions
                test_file = dir_path / '.write_test'
                test_file.touch()
                test_file.unlink()
            except (PermissionError, OSError):
                warnings.append(
                    f"Warning: Limited permissions on '{dir_name}' directory"
                )
    
    # Check content structure
    content_path = Path('content/pages')
    if not content_path.exists() or not any(content_path.iterdir()):
        warnings.append("No content found - creating welcome page")
        try:
            create_welcome_page()
        except Exception as e:
            warnings.append(f"Failed to create welcome page: {str(e)}")
    
    return errors, warnings

class FileChangeHandler(FileSystemEventHandler):
    """Handler for file system changes."""
    
    def __init__(self, callback):
        self.callback = callback
        
    def on_modified(self, event):
        if not event.is_directory:
            self.callback(event.src_path)


class DevServer:
    """Development server with hot reload support."""
    
    def __init__(self, config: Config, host: str = 'localhost', port: int = 8000):
        self.config = config
        self.host = host
        self.port = port
        self.engine = Engine(config)
        
        # Validate project structure before starting
        errors, warnings = validate_project_structure()
        
        if errors:
            console.print(Panel(
                "\n".join([
                    "[red]Critical errors found:[/red]",
                    *[f"• {error}" for error in errors],
                    "\n[yellow]Please fix these issues before starting the server:[/yellow]",
                    "1. Make sure you're in the correct project directory",
                    "2. Check if all required directories and files exist",
                    "3. Verify file and directory permissions",
                    "\nProject structure should be:",
                    "project_name/",
                    "├── content/",
                    "│   └── pages/",
                    "├── templates/",
                    "├── static/",
                    "├── public/",
                    "└── config.toml"
                ]),
                title="[red]Project Structure Errors[/red]",
                border_style="red"
            ))
            raise SystemExit(1)
        
        if warnings:
            console.print(Panel(
                "\n".join([
                    "[yellow]Warnings:[/yellow]",
                    *[f"• {warning}" for warning in warnings]
                ]),
                title="[yellow]Project Structure Warnings[/yellow]",
                border_style="yellow"
            ))
            
        # Build the site before starting server
        self.engine.build()
        
    async def handle_request(self, request):
        """Handle incoming HTTP request."""
        path = request.path
        
        # Serve files from public directory
        if path == "/":
            path = "/index.html"
            
        file_path = Path(self.config.get("output_dir")) / path.lstrip("/")
        
        if not file_path.exists():
            return web.Response(status=404, text="Not Found")
            
        if not file_path.is_file():
            return web.Response(status=403, text="Forbidden")
            
        content_type = "text/html"
        if path.endswith(".css"):
            content_type = "text/css"
        elif path.endswith(".js"):
            content_type = "application/javascript"
            
        return web.FileResponse(file_path, headers={"Content-Type": content_type})
        
    def start(self):
        """Start the development server."""
        app = web.Application()
        app.router.add_get('/{tail:.*}', self.handle_request)
        
        web.run_app(app, host=self.host, port=self.port) 