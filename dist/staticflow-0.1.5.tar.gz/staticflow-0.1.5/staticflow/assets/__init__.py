from .manager import AssetManager

__all__ = ['AssetManager'] 